package com.example.control_spinner_tom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText et1, clave;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.et1);
        clave = findViewById(R.id.clave);
    }

    public void confirmar(View view){
        String usuario = et1.getText().toString();
        String secreto = clave.getText().toString();

        if(secreto.length() > 0 && usuario.length() > 0){
            Toast notification = Toast.makeText(this, "Bienvenido Usuario", Toast.LENGTH_LONG);
            notification.show();
        }
        else{
            Toast notification = Toast.makeText(this, "El nombre o Clave no puede estar vacia", Toast.LENGTH_LONG);
            notification.show();
        }
    }
}