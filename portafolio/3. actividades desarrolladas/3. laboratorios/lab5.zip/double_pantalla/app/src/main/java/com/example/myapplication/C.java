package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class C extends AppCompatActivity {

    private EditText check_et1,check_et2;
    private TextView check_txt;
    private CheckBox check1, check2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        check_et1 = findViewById(R.id.check_et1);
        check_et2 = findViewById(R.id.check_et2);
        check_txt = findViewById(R.id.check_txt);
        check1 = findViewById(R.id.check1);
        check2 = findViewById(R.id.check2);

    }

    public void calcular_check(View view){
        String valor1 = check_et1.getText().toString();
        String valor2 = check_et2.getText().toString();

        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);
        int result = 0;


        if(check1.isChecked() && !check2.isChecked()){
            result = num1 + num2;
            imprimir_check(result);
        }
        else if(check2.isChecked() && !check1.isChecked()){
            result = num1 - num2;
            imprimir_check(result);
        }
    }
    public void imprimir_check(int result){
        String r = String.valueOf(result);
        check_txt.setText(r);
    }
    public void salir_check(View view){
        finish();
    }
}