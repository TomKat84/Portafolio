package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class acerca_de extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca_de);
    }

    public void comboBox(View view){
        Intent i = new Intent(this, comboBox.class);
        startActivity(i);
    }
    public void radioButton(View view){
        Intent i = new Intent(this, radioButton.class);
        startActivity(i);
    }
    public void checkBox(View view){
        Intent i = new Intent(this, C.class);
        startActivity(i);
    }
    public void switch_activity(View view){
        Intent i = new Intent(this, switch_activity.class);
        startActivity(i);
    }
    public void imagen_icon(View view){
        Intent i = new Intent(this, imagen_icon.class);
        startActivity(i);
    }


    public void salir(View view){
        finish();
    }
}