package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class comboBox extends AppCompatActivity {

    private EditText et1, et2;
    private TextView txt;

    private Spinner spinner1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combo_box);

        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        txt = findViewById(R.id.txt);

        spinner1 = findViewById(R.id.spinner);
        String[] op = {"sumar", "restar", "multiplicar", "dividir"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, op);
        spinner1.setAdapter(adapter);
    }

    public void calcular(View view){
        String valor1 = et1.getText().toString();
        String valor2 = et2.getText().toString();

        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);
        int r = 0;
        String valor = "";

        String select =spinner1.getSelectedItem().toString();

        if(select.equals("sumar")){
            r = num1 + num2;
            valor = String.valueOf(r);
            this.imprimir(valor);
        }
        else if(select.equals("restar")){
            r = num1 - num2;
            valor = String.valueOf(r);
            this.imprimir(valor);
        }
        else if(select.equals("multiplicar")){
            r = num1 * num2;
            valor = String.valueOf(r);
            this.imprimir(valor);
        }
        else if(select.equals("dividir")){
            r = num1 / num2;
            valor = String.valueOf(r);
            this.imprimir(valor);
        }
    }
    public void imprimir(String valor){
        txt.setText(valor);
    }

    public void regresar(View view){
        finish();
    }
}