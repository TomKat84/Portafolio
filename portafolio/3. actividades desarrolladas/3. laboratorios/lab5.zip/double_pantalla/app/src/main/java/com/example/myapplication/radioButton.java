package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class radioButton extends AppCompatActivity {

    private EditText rad_et1, rad_et2;
    private TextView rad_txt;
    private RadioButton r1,r2,r3,r4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_button);

        rad_et1 = findViewById(R.id.rad_et1);
        rad_et2 = findViewById(R.id.rad_et2);
        rad_txt = findViewById(R.id.rad_txt);

        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);
        r4 = findViewById(R.id.r4);
    }

    public void operar(View view){
        String valor1 = rad_et1.getText().toString();
        String valor2 = rad_et2.getText().toString();

        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);

        if(r1.isChecked()){
            int suma = num1 + num2;
            String result = String.valueOf(suma);
            this.imprimir_rad(result);
        }
        else if(r2.isChecked()){
            int resta = num1 - num2;
            String result = String.valueOf(resta);
            this.imprimir_rad(result);
        }
        else if(r3.isChecked()){
            int resta = num1 * num2;
            String result = String.valueOf(resta);
            this.imprimir_rad(result);
        }
        else if(r4.isChecked()){
            int resta = num1 / num2;
            String result = String.valueOf(resta);
            this.imprimir_rad(result);
        }
    }
    public void imprimir_rad(String result) {
        rad_txt.setText(result);
    }
    public void salir_rad(View view){
        finish();
    }
}