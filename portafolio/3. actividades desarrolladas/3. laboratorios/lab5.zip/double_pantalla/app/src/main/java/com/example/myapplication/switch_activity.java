package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

public class switch_activity extends AppCompatActivity {

    private Switch switch1, switch2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch);

        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
    }

    public void verificar_datos(View view){
        if(switch1.isChecked()){
            Toast.makeText(this, "Datos moviles activados", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "Datos moviles desactivados", Toast.LENGTH_LONG).show();
        }
    }
    public void verificar_wifi(View view){
        if(switch2.isChecked()){
            Toast.makeText(this, "WIFI activados", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "WIFI desactivados", Toast.LENGTH_LONG).show();
        }
    }

    public void salir_switch(View view){
        finish();
    }
}