package com.example.calculoareatriangulo_tom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2, et3;
    private RadioButton r1, r2, r3;
    private CheckBox lado_a, lado_b, lado_c;
    private TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);

        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);

        lado_a = findViewById(R.id.lado_a);
        lado_b = findViewById(R.id.lado_b);
        lado_c = findViewById(R.id.lado_c);

        txt = findViewById(R.id.txt);

        et1.setText("0");
        et2.setText("0");
        et3.setText("0");
    }

    public void calcular(View view){
        try {
            String valor1 = et1.getText().toString();
            String valor2 = et2.getText().toString();
            String valor3 = et3.getText().toString();

            float num1 = Float.parseFloat(valor1);
            float num2 = Float.parseFloat(valor2);
            float num3 = Float.parseFloat(valor3);

            if(r1.isChecked()){
                if(lado_a.isChecked() && !lado_b.isChecked() && !lado_c.isChecked()){
                    double equilatero = (Math.sqrt(3) * (num1 * num1)) / 4;
                    String resultado = String.valueOf(equilatero);
                    txt.setText(resultado);
                }
                else if(!lado_a.isChecked() && lado_b.isChecked() && !lado_c.isChecked()){
                    double equilatero = (Math.sqrt(3) * (num2 * num2)) / 4;
                    String resultado = String.valueOf(equilatero);
                    txt.setText(resultado);
                }
                else if(!lado_a.isChecked() && !lado_b.isChecked() && lado_c.isChecked()){
                    double equilatero = (Math.sqrt(3) * (num3 * num3)) / 4;
                    String resultado = String.valueOf(equilatero);
                    txt.setText(resultado);
                }
            }
            else if(r2.isChecked()){
                if(lado_a.isChecked() && !lado_b.isChecked() && lado_c.isChecked()){
                    double b = num3 / 2;
                    double h = Math.sqrt((num1 * num1) - (b * b));
                    double isosceles = (num3 * h) / 2;
                    String resultado = String.valueOf(isosceles);
                    txt.setText(resultado);
                }
                else if(!lado_a.isChecked() && lado_b.isChecked() && lado_c.isChecked()){
                    double b = num3 / 2;
                    double h = Math.sqrt((num2 * num2) - (b * b));
                    double isosceles = (num3 * h) / 2;
                    String resultado = String.valueOf(isosceles);
                    txt.setText(resultado);
                }
            }
            else if(r3.isChecked()){
                double escaleno = (num1 * num3) / 2;
                String resultado = String.valueOf(escaleno);
                txt.setText(resultado);
            }
        }
        catch (Exception e){

        }
    }
}