package com.example.finalp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Adaptador extends BaseAdapter {

    private Context context;
    private ArrayList<Entradas> listItems;

    public Adaptador(Context context, ArrayList<Entradas> listItems){
        this.context = context;
        this.listItems = listItems;
    }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        Entradas Item = (Entradas) getItem(i);

        view = LayoutInflater.from(context).inflate(R.layout.item_personalizado, null);
        ImageView imagen = view.findViewById(R.id.imagen);
        TextView name = view.findViewById(R.id.name);
        TextView category = view.findViewById(R.id.category);
        TextView fees = view.findViewById(R.id.fees);

        imagen.setImageResource(Item.getImagen());
        name.setText(Item.getName());
        category.setText(Item.getCategory());
        fees.setText(Item.getFees());

        return view;
    }

    @Override
    public int getCount() {
        return listItems.size();
    }

    @Override
    public Object getItem(int i) {
        return listItems.get(i);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

}
