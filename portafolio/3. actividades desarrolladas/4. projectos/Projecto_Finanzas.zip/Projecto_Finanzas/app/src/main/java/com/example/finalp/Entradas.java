package com.example.finalp;

public class Entradas {

    private int imagen;
    private String name;
    private String type;
    private String category;
    private String fees;

    public Entradas(int imagen, String name, String type, String category, String fees){
        this.imagen = imagen;
        this.name = name;
        this.type = type;
        this.category = category;
        this.fees = fees;
    }

    public int getImagen(){return imagen;}

    public String getName(){
        return name;
    }
    public String getType(){
        return type;
    }
    public String getCategory(){
        return category;
    }
    public String getFees(){return fees;}
}
