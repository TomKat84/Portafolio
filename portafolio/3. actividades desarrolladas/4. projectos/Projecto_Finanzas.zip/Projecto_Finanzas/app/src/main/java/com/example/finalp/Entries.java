package com.example.finalp;

public class Entries {
    String id;
    String name;
    String type;
    String category;
    String fees;
}
