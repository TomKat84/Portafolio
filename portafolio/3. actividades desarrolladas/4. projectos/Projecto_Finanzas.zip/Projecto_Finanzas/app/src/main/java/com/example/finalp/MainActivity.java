package com.example.finalp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list1;
    Adaptador adaptador;
    //ArrayList<String> titles = new ArrayList<>();
    ArrayList<Entradas> titles = new ArrayList<>();
    ArrayList<Double> total = new ArrayList<>();

    TextView txt;
    ArrayAdapter arrayAdapter;

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txt = findViewById(R.id.result);

        //AQUI CREARA LAS TABLAS QUE SE NECESITAN, LA BASE DE DATO SE LLAMARA "Cuentas"
        SQLiteDatabase db = openOrCreateDatabase("Cuentas", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR, type VARCHAR, category VARCHAR, fees REAL)");

        list1 = findViewById(R.id.list1);

        final Cursor c = db.rawQuery("SELECT * FROM entries", null);
        int id = c.getColumnIndex("id");
        int name = c.getColumnIndex("name");
        int type = c.getColumnIndex("type");
        int category = c.getColumnIndex("category");
        int fees = c.getColumnIndex("fees");
        titles.clear();

        arrayAdapter = new ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, titles);


        //titles.add(new Entradas(R.drawable.sumar, "Quincena", "pago de la semana", "123", "123"));

        adaptador = new Adaptador(this, titles);
        list1.setAdapter(adaptador);

        final ArrayList<Entries> ent = new ArrayList<Entries>();

        if(c.moveToFirst()){
            do{
                Entries en = new Entries();
                en.id = c.getString(id);
                en.name = c.getString(name);
                en.type = c.getString(type);
                en.category = c.getString(category);
                en.fees = c.getString(fees);

                ent.add(en);

                if(en.type.equals("Ingresos")){
                    titles.add(new Entradas(R.drawable.sumar, c.getString(name),c.getString(type), c.getString(category), c.getString(fees)));
                    total.add(Double.parseDouble(en.fees));
                }
                else if(en.type.equals("Egresos")){
                    titles.add(new Entradas(R.drawable.restar, c.getString(name),c.getString(type), c.getString(category), c.getString(fees)));
                    total.add(-Double.parseDouble(en.fees));
                }

            }while(c.moveToNext());

            //CODIGO PARA OBTENER EL RESULTADO DE LAS SUMAS Y RESTAS
            Double totales = 0.00;
            for (int i=0; i<total.size(); i++){
                totales = totales + total.get(i);
            }
            totales = (double) Math.round(totales * 100) / 100;
            String resultado = String.valueOf(totales);
            txt.setText("Total: " + resultado);


            arrayAdapter.notifyDataSetChanged();
            list1.invalidateViews();
        }

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Entradas aa = titles.get(position);

                //Toast.makeText(getApplicationContext(), aa, Toast.LENGTH_LONG).show();

                Entries en = ent.get(position);

                Intent i = new Intent(getApplicationContext(), editEntries.class);
                i.putExtra("id", en.id);
                i.putExtra("name", en.name);
                i.putExtra("category", en.category);
                i.putExtra("fees", en.fees);
                startActivity(i);
            }
        });
    }

    public void insertEntries(View v){
        Intent i = new Intent(this, insertEntries.class);
        startActivity(i);
    }
}