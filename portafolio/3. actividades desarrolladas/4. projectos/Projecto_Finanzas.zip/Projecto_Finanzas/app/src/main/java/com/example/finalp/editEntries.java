package com.example.finalp;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class editEntries extends AppCompatActivity {

    EditText ed1, ed2, ed3, ed4;
    Spinner spinner1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_entries);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);
        ed4 = findViewById(R.id.ed4);

        spinner1 = findViewById(R.id.spinner1);
        String[] opcion = {"N/A", "Ingresos", "Egresos"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, opcion);
        spinner1.setAdapter(adapter);

        Intent i = getIntent();
        String t1 = i.getStringExtra("id").toString();
        String t2 = i.getStringExtra("name").toString();
        String t3 = i.getStringExtra("category").toString();
        String t4 = i.getStringExtra("fees").toString();

        ed4.setText(t1);
        ed1.setText(t2);
        ed2.setText(t3);
        ed3.setText(t4);
    }

    public void updated(View v){
        try{
            String name = ed1.getText().toString();
            String category = ed2.getText().toString();
            String fees = ed3.getText().toString();
            String id = ed4.getText().toString();
            String select = spinner1.getSelectedItem().toString();

            SQLiteDatabase db = openOrCreateDatabase("Cuentas", Context.MODE_PRIVATE, null);

            String sql = "UPDATE entries set name=?, type=?, category=?, fees=? WHERE id=?";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, name);
            statement.bindString(2, select);
            statement.bindString(3, category);
            statement.bindString(4, fees);
            statement.bindString(5, id);
            statement.execute();
            Toast.makeText(this, "RECORD UPDATED", Toast.LENGTH_LONG).show();

        }
        catch (Exception ex){
            Toast.makeText(this, "RECORD FAILED", Toast.LENGTH_LONG).show();
        }
    }

    public void delete(View v){
        try{
            String id = ed4.getText().toString();

            SQLiteDatabase db = openOrCreateDatabase("Cuentas", Context.MODE_PRIVATE, null);

            String sql = "DELETE FROM entries WHERE id=?";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, id);
            statement.execute();
            Toast.makeText(this, "RECORD DELETED", Toast.LENGTH_LONG).show();

        }
        catch (Exception ex){
            Toast.makeText(this, "RECORD FAILED", Toast.LENGTH_LONG).show();
        }
    }

    public void back(View v){
        //Intent i = new Intent(this, views.class);
        //startActivity(i);
        finish();
    }
}