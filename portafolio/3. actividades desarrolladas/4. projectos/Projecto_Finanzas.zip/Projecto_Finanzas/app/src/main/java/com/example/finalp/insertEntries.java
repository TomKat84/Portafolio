package com.example.finalp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class insertEntries extends AppCompatActivity {

    Spinner spinner1;
    EditText ed1,ed2,ed3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_insert_entries);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);

        spinner1 = findViewById(R.id.spinner1);
        String[] opcion = {"N/A", "Ingresos", "Egresos"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, opcion);
        spinner1.setAdapter(adapter);
    }

    public void insert(View v){
        try{
            String name = ed1.getText().toString();
            String category = ed2.getText().toString();
            String fees = ed3.getText().toString();
            String select = spinner1.getSelectedItem().toString();

            SQLiteDatabase db = openOrCreateDatabase("Cuentas", Context.MODE_PRIVATE, null);

            String sql = "INSERT INTO entries(name,type,category,fees) VALUES(?,?,?,?);";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, name);
            statement.bindString(2, select);
            statement.bindString(3, category);
            statement.bindString(4, fees);
            statement.execute();
            Toast.makeText(this, "RECORD ADDED", Toast.LENGTH_LONG).show();

            ed1.setText("");
            ed2.setText("");
            ed3.setText("");

            ed1.requestFocus();

        }
        catch (Exception ex){
            Toast.makeText(this, "RECORD FAILED", Toast.LENGTH_LONG).show();
        }
    }

    public void back(View v){
        finish();
    }
}